#include "ur3_d/letter_d_path.hpp"

#include <cmath>
#include <cstddef>

#include <geometry_msgs/msg/point.hpp>

namespace ur3_d
{
namespace
{
geometry_msgs::msg::Pose makePose(
  const geometry_msgs::msg::Pose & reference,
  const double x,
  const double y,
  const double z)
{
  auto pose = reference;
  pose.position.x = x;
  pose.position.y = y;
  pose.position.z = z;
  return pose;
}

geometry_msgs::msg::Point toPoint(const geometry_msgs::msg::Pose & pose)
{
  geometry_msgs::msg::Point point;
  point.x = pose.position.x;
  point.y = pose.position.y;
  point.z = pose.position.z;
  return point;
}
}  // namespace

Strokes createLetterDStrokes(
  const geometry_msgs::msg::Pose & reference_pose,
  const double letter_height,
  const double letter_width)
{
  const double center_x = reference_pose.position.x;
  const double y_left = reference_pose.position.y - letter_width / 2.0;
  const double x_top = center_x + letter_height / 2.0;
  const double x_bottom = center_x - letter_height / 2.0;
  const double z_draw = reference_pose.position.z;

  Strokes strokes;
  strokes.push_back(
    {
      makePose(reference_pose, x_top, y_left, z_draw),
      makePose(reference_pose, x_bottom, y_left, z_draw)});

  Stroke round_stroke;
  constexpr int arc_points = 18;
  constexpr double pi = 3.14159265358979323846;
  for (int i = 0; i <= arc_points; ++i) {
    const double t = static_cast<double>(i) / static_cast<double>(arc_points);
    const double theta = pi / 2.0 - t * pi;
    const double x = center_x + (letter_height / 2.0) * std::sin(theta);
    const double y = y_left + letter_width * std::cos(theta);
    round_stroke.push_back(makePose(reference_pose, x, y, z_draw));
  }
  strokes.push_back(round_stroke);

  const double crossbar_half_length = letter_width * 0.22;
  strokes.push_back(
    {
      makePose(reference_pose, center_x, y_left - crossbar_half_length, z_draw),
      makePose(reference_pose, center_x, y_left + crossbar_half_length, z_draw)});
  return strokes;
}

std::vector<geometry_msgs::msg::Pose> createMotionWaypoints(
  const Strokes & strokes,
  const double lift_height)
{
  std::vector<geometry_msgs::msg::Pose> waypoints;
  for (const auto & stroke : strokes) {
    if (stroke.empty()) {
      continue;
    }

    auto above_start = stroke.front();
    above_start.position.z += lift_height;
    auto above_end = stroke.back();
    above_end.position.z += lift_height;

    waypoints.push_back(above_start);
    waypoints.push_back(stroke.front());
    waypoints.insert(waypoints.end(), stroke.begin(), stroke.end());
    waypoints.push_back(above_end);
  }
  return waypoints;
}

visualization_msgs::msg::Marker createPathMarker(
  const Strokes & strokes,
  const std::string & frame_id)
{
  visualization_msgs::msg::Marker marker;
  marker.header.frame_id = frame_id;
  marker.ns = "letter_d_path";
  marker.id = 0;
  marker.type = visualization_msgs::msg::Marker::LINE_LIST;
  marker.action = visualization_msgs::msg::Marker::ADD;
  marker.pose.orientation.w = 1.0;
  marker.scale.x = 0.006;
  marker.color.r = 0.05;
  marker.color.g = 0.75;
  marker.color.b = 1.0;
  marker.color.a = 1.0;

  for (const auto & stroke : strokes) {
    for (std::size_t i = 1; i < stroke.size(); ++i) {
      marker.points.push_back(toPoint(stroke[i - 1]));
      marker.points.push_back(toPoint(stroke[i]));
    }
  }
  return marker;
}
}  // namespace ur3_d
