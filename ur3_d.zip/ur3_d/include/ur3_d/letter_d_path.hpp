#pragma once

#include <string>
#include <vector>

#include <geometry_msgs/msg/pose.hpp>
#include <visualization_msgs/msg/marker.hpp>

namespace ur3_d
{
using Stroke = std::vector<geometry_msgs::msg::Pose>;
using Strokes = std::vector<Stroke>;

Strokes createLetterDStrokes(
  const geometry_msgs::msg::Pose & reference_pose,
  double letter_height,
  double letter_width);

std::vector<geometry_msgs::msg::Pose> createMotionWaypoints(
  const Strokes & strokes,
  double lift_height);

visualization_msgs::msg::Marker createPathMarker(
  const Strokes & strokes,
  const std::string & frame_id);
}  // namespace ur3_d
