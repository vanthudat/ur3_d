from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, TimerAction
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    ur_type = LaunchConfiguration("ur_type")
    start_writer = LaunchConfiguration("start_writer")
    writer_delay = LaunchConfiguration("writer_delay")
    kinematics_yaml = PathJoinSubstitution(
        [FindPackageShare("ur_moveit_config"), "config", "kinematics.yaml"]
    )
    writer_yaml = PathJoinSubstitution(
        [FindPackageShare("ur3_d"), "config", "writer.yaml"]
    )

    ur_sim_control = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            [
                FindPackageShare("ur_simulation_gz"),
                "/launch/ur_sim_control.launch.py",
            ]
        ),
        launch_arguments={
            "ur_type": ur_type,
            "launch_rviz": "false",
        }.items(),
    )

    ur_moveit = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            [
                FindPackageShare("ur3_d"),
                "/launch/moveit_rviz.launch.py",
            ]
        ),
        launch_arguments={
            "ur_type": ur_type,
            "use_sim_time": "true",
            "launch_rviz": "true",
        }.items(),
    )

    write_letter_node = TimerAction(
        period=writer_delay,
        actions=[
            Node(
                package="ur3_d",
                executable="write_letter_d_node",
                name="write_letter_d_node",
                output="screen",
                parameters=[
                    writer_yaml,
                    kinematics_yaml,
                    {
                        "use_sim_time": True,
                    }
                ],
            )
        ],
        condition=IfCondition(start_writer),
    )

    return LaunchDescription(
        [
            DeclareLaunchArgument(
                "ur_type",
                default_value="ur3",
                description="UR robot type to simulate.",
            ),
            DeclareLaunchArgument(
                "start_writer",
                default_value="false",
                description=(
                    "Start the writer automatically; keep false for the "
                    "two-command workflow."
                ),
            ),
            DeclareLaunchArgument(
                "writer_delay",
                default_value="25.0",
                description="Delay before starting the writer node.",
            ),
            ur_sim_control,
            ur_moveit,
            write_letter_node,
        ]
    )
