#pragma once

#include <string>
#include <vector>

#include <geometry_msgs/msg/pose.hpp>

namespace ur3_image_writer
{
using Stroke = std::vector<geometry_msgs::msg::Pose>;
using Strokes = std::vector<Stroke>;

struct ImagePathOptions
{
  double cartesian_height{0.13};
  double cartesian_width{0.08};
  double min_contour_area{50.0};
  double simplify_epsilon{2.0};
  double resample_spacing{5.0};
  bool invert{true};
};

Strokes createStrokesFromImage(
  const std::string & image_path,
  const geometry_msgs::msg::Pose & reference_pose,
  const ImagePathOptions & options);

std::vector<geometry_msgs::msg::Pose> createMotionWaypoints(
  const Strokes & strokes,
  double lift_height);

std::vector<geometry_msgs::msg::Pose> createStrokeWaypoints(
  const Stroke & stroke,
  double lift_height);
}  // namespace ur3_image_writer
