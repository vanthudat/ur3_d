#pragma once

#include <string>
#include <vector>

#include <geometry_msgs/msg/pose.hpp>
#include <moveit/move_group_interface/move_group_interface.h>
#include <rclcpp/logger.hpp>

#include "ur3_image_writer/image_path_processor.hpp"

namespace ur3_image_writer
{
bool moveToNamedTarget(
  moveit::planning_interface::MoveGroupInterface & move_group,
  const std::string & target_name,
  const rclcpp::Logger & logger,
  bool execute_motion);

bool moveToNamedTargetWithVerticalOffset(
  moveit::planning_interface::MoveGroupInterface & move_group,
  const std::string & target_name,
  const rclcpp::Logger & logger,
  double vertical_offset,
  bool execute_motion);

bool executeCartesianPath(
  moveit::planning_interface::MoveGroupInterface & move_group,
  const std::vector<geometry_msgs::msg::Pose> & waypoints,
  const rclcpp::Logger & logger,
  double eef_step,
  double min_fraction,
  bool avoid_collisions,
  bool execute_motion);

bool executeCartesianStrokes(
  moveit::planning_interface::MoveGroupInterface & move_group,
  const Strokes & strokes,
  const rclcpp::Logger & logger,
  double lift_height,
  double eef_step,
  double min_fraction,
  bool avoid_collisions,
  bool execute_motion,
  double transit_velocity_scale,
  double draw_velocity_scale);
}  // namespace ur3_image_writer
