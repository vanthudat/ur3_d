#include <algorithm>
#include <cmath>
#include <cstddef>
#include <limits>
#include <string>

#include <gtest/gtest.h>

#include "ur3_image_writer/image_path_processor.hpp"

#ifndef TEST_IMAGE_PATH
#error "TEST_IMAGE_PATH must be defined"
#endif

TEST(ImagePathProcessor, ProcessesProjectInputImage)
{
  geometry_msgs::msg::Pose reference;
  reference.position.x = -0.1;
  reference.position.y = 0.27;
  reference.position.z = 0.35;
  reference.orientation.w = 1.0;

  ur3_image_writer::ImagePathOptions options;
  options.cartesian_height = 0.13;
  options.cartesian_width = 0.08;
  options.simplify_epsilon = 4.0;
  options.resample_spacing = 20.0;
  const auto strokes = ur3_image_writer::createStrokesFromImage(
    TEST_IMAGE_PATH, reference, options);

  ASSERT_EQ(strokes.size(), 3U);
  std::size_t point_count = 0;
  std::size_t open_stroke_count = 0;
  double min_x = std::numeric_limits<double>::max();
  double max_x = std::numeric_limits<double>::lowest();
  double min_y = std::numeric_limits<double>::max();
  double max_y = std::numeric_limits<double>::lowest();
  for (const auto & stroke : strokes) {
    EXPECT_GE(stroke.size(), 2U);
    point_count += stroke.size();
    for (const auto & pose : stroke) {
      EXPECT_DOUBLE_EQ(pose.position.z, reference.position.z);
      min_x = std::min(min_x, pose.position.x);
      max_x = std::max(max_x, pose.position.x);
      min_y = std::min(min_y, pose.position.y);
      max_y = std::max(max_y, pose.position.y);
    }
    const auto & first = stroke.front().position;
    const auto & last = stroke.back().position;
    if (first.x != last.x || first.y != last.y) {
      ++open_stroke_count;
    }
  }
  EXPECT_GT(open_stroke_count, 0U);

  const auto longest_stroke = std::max_element(
    strokes.begin(), strokes.end(),
    [](const auto & left, const auto & right) {return left.size() < right.size();});
  const auto & loop_start = longest_stroke->front().position;
  const auto & loop_end = longest_stroke->back().position;
  EXPECT_LT(std::hypot(loop_end.x - loop_start.x, loop_end.y - loop_start.y), 0.001);
  EXPECT_GT(max_x - min_x, 0.07);
  EXPECT_GT(max_y - min_y, 0.06);

  double stem_min_x = std::numeric_limits<double>::max();
  double stem_max_x = std::numeric_limits<double>::lowest();
  const double stem_y_limit = min_y + 0.30 * (max_y - min_y);
  for (const auto & stroke : strokes) {
    for (const auto & pose : stroke) {
      if (pose.position.y <= stem_y_limit) {
        stem_min_x = std::min(stem_min_x, pose.position.x);
        stem_max_x = std::max(stem_max_x, pose.position.x);
      }
    }
  }
  EXPECT_GT(stem_max_x - stem_min_x, 0.65 * (max_x - min_x));
  EXPECT_GT(point_count, 20U);
  EXPECT_LT(point_count, 500U);
}

TEST(ImagePathProcessor, BuildsAnIndependentStrokeMotion)
{
  geometry_msgs::msg::Pose first;
  first.position.x = 0.1;
  first.position.z = 0.2;
  geometry_msgs::msg::Pose last = first;
  last.position.x = 0.2;

  const auto waypoints = ur3_image_writer::createStrokeWaypoints({first, last}, 0.05);

  ASSERT_EQ(waypoints.size(), 3U);
  EXPECT_DOUBLE_EQ(waypoints.front().position.x, first.position.x);
  EXPECT_DOUBLE_EQ(waypoints.front().position.z, first.position.z);
  EXPECT_DOUBLE_EQ(waypoints[1].position.x, last.position.x);
  EXPECT_DOUBLE_EQ(waypoints.back().position.x, last.position.x);
  EXPECT_DOUBLE_EQ(waypoints.back().position.z, last.position.z + 0.05);
}
