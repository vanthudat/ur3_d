#include "ur3_image_writer/moveit_executor.hpp"

#include <algorithm>
#include <cstddef>

#include <moveit/robot_state/robot_state.h>
#include <moveit_msgs/msg/robot_trajectory.hpp>

namespace ur3_image_writer
{
bool moveToNamedTarget(
  moveit::planning_interface::MoveGroupInterface & move_group,
  const std::string & target_name,
  const rclcpp::Logger & logger,
  const bool execute_motion)
{
  move_group.setStartStateToCurrentState();
  move_group.setNamedTarget(target_name);
  moveit::planning_interface::MoveGroupInterface::Plan plan;
  if (!static_cast<bool>(move_group.plan(plan))) {
    RCLCPP_ERROR(logger, "Could not plan to named target '%s'.", target_name.c_str());
    return false;
  }
  if (!execute_motion) {
    return true;
  }
  return static_cast<bool>(move_group.execute(plan));
}

bool moveToNamedTargetWithVerticalOffset(
  moveit::planning_interface::MoveGroupInterface & move_group,
  const std::string & target_name,
  const rclcpp::Logger & logger,
  const double vertical_offset,
  const bool execute_motion)
{
  const auto named_values = move_group.getNamedTargetValues(target_name);
  if (named_values.empty()) {
    RCLCPP_ERROR(logger, "Named target '%s' does not exist.", target_name.c_str());
    return false;
  }

  const auto robot_model = move_group.getRobotModel();
  const auto * joint_model_group = robot_model->getJointModelGroup(move_group.getName());
  if (joint_model_group == nullptr) {
    RCLCPP_ERROR(logger, "Could not load joint model group '%s'.", move_group.getName().c_str());
    return false;
  }

  moveit::core::RobotState target_state(robot_model);
  target_state.setToDefaultValues();
  target_state.setVariablePositions(named_values);
  target_state.update();

  const std::string end_effector_link = move_group.getEndEffectorLink();
  auto target_transform = target_state.getGlobalLinkTransform(end_effector_link);
  target_transform.translation().z() += vertical_offset;
  if (!target_state.setFromIK(
      joint_model_group, target_transform, end_effector_link, 0.1))
  {
    RCLCPP_ERROR(
      logger, "Could not solve the safe pose %.3f m above named target '%s'.",
      vertical_offset, target_name.c_str());
    return false;
  }

  std::vector<double> target_joint_values;
  target_state.copyJointGroupPositions(joint_model_group, target_joint_values);
  move_group.setStartStateToCurrentState();
  if (!move_group.setJointValueTarget(target_joint_values)) {
    RCLCPP_ERROR(logger, "Safe named target is outside the joint limits.");
    return false;
  }

  moveit::planning_interface::MoveGroupInterface::Plan plan;
  if (!static_cast<bool>(move_group.plan(plan))) {
    RCLCPP_ERROR(logger, "Could not plan directly to the safe writing pose.");
    return false;
  }
  if (!execute_motion) {
    return true;
  }
  return static_cast<bool>(move_group.execute(plan));
}

bool executeCartesianPath(
  moveit::planning_interface::MoveGroupInterface & move_group,
  const std::vector<geometry_msgs::msg::Pose> & waypoints,
  const rclcpp::Logger & logger,
  const double eef_step,
  const double min_fraction,
  const bool avoid_collisions,
  const bool execute_motion)
{
  move_group.setStartStateToCurrentState();
  moveit_msgs::msg::RobotTrajectory trajectory;
  const double fraction = move_group.computeCartesianPath(
    waypoints, eef_step, 0.0, trajectory, avoid_collisions);
  RCLCPP_INFO(logger, "Image Cartesian path fraction: %.2f%%", fraction * 100.0);
  if (fraction < min_fraction) {
    return false;
  }
  if (!execute_motion) {
    return true;
  }
  moveit::planning_interface::MoveGroupInterface::Plan plan;
  plan.trajectory_ = trajectory;
  return static_cast<bool>(move_group.execute(plan));
}

bool executeCartesianStrokes(
  moveit::planning_interface::MoveGroupInterface & move_group,
  const Strokes & strokes,
  const rclcpp::Logger & logger,
  const double lift_height,
  const double eef_step,
  const double min_fraction,
  const bool avoid_collisions,
  const bool execute_motion,
  const double transit_velocity_scale,
  const double draw_velocity_scale)
{
  bool all_succeeded = true;
  std::size_t completed = 0;
  for (std::size_t index = 0; index < strokes.size(); ++index) {
    const auto & stroke = strokes[index];
    if (stroke.empty()) {
      continue;
    }

    auto above_start = stroke.front();
    above_start.position.z += lift_height;
    const auto current_pose = move_group.getCurrentPose().pose;
    auto safe_current = current_pose;
    safe_current.position.z = std::max(current_pose.position.z, above_start.position.z);
    const std::vector<geometry_msgs::msg::Pose> transit_waypoints{safe_current, above_start};
    move_group.setMaxVelocityScalingFactor(transit_velocity_scale);
    if (!executeCartesianPath(
        move_group, transit_waypoints, logger, eef_step, min_fraction,
        avoid_collisions, execute_motion))
    {
      RCLCPP_ERROR(
        logger, "Stroke %zu: safe transit path failed.", index + 1U);
      all_succeeded = false;
      continue;
    }

    move_group.setMaxVelocityScalingFactor(draw_velocity_scale);
    const auto draw_waypoints = createStrokeWaypoints(stroke, lift_height);
    if (!executeCartesianPath(
        move_group, draw_waypoints, logger, eef_step, min_fraction,
        avoid_collisions, execute_motion))
    {
      RCLCPP_ERROR(logger, "Stroke %zu: drawing path failed.", index + 1U);
      all_succeeded = false;
      continue;
    }
    ++completed;
    RCLCPP_INFO(logger, "Completed stroke %zu/%zu.", index + 1U, strokes.size());
  }
  RCLCPP_INFO(logger, "Completed %zu/%zu image strokes.", completed, strokes.size());
  return all_succeeded && completed == strokes.size();
}
}  // namespace ur3_image_writer
