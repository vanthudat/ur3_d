#include <chrono>
#include <exception>
#include <memory>
#include <string>
#include <thread>

#include <ament_index_cpp/get_package_share_directory.hpp>
#include <geometry_msgs/msg/point.hpp>
#include <moveit/move_group_interface/move_group_interface.h>
#include <rclcpp/rclcpp.hpp>
#include <visualization_msgs/msg/marker.hpp>
#include <visualization_msgs/msg/marker_array.hpp>

#include "ur3_image_writer/image_path_processor.hpp"
#include "ur3_image_writer/moveit_executor.hpp"

namespace
{
visualization_msgs::msg::Marker createMarker(
  const ur3_image_writer::Strokes & strokes,
  const std::string & frame_id)
{
  visualization_msgs::msg::Marker marker;
  marker.header.frame_id = frame_id;
  marker.ns = "image_cartesian_path";
  marker.id = 0;
  marker.type = visualization_msgs::msg::Marker::LINE_LIST;
  marker.action = visualization_msgs::msg::Marker::ADD;
  marker.pose.orientation.w = 1.0;
  marker.scale.x = 0.006;
  marker.color.r = 0.05;
  marker.color.g = 0.75;
  marker.color.b = 1.0;
  marker.color.a = 1.0;
  for (const auto & stroke : strokes) {
    for (std::size_t i = 1; i < stroke.size(); ++i) {
      geometry_msgs::msg::Point start;
      start.x = stroke[i - 1].position.x;
      start.y = stroke[i - 1].position.y;
      start.z = stroke[i - 1].position.z;
      geometry_msgs::msg::Point end;
      end.x = stroke[i].position.x;
      end.y = stroke[i].position.y;
      end.z = stroke[i].position.z;
      marker.points.push_back(start);
      marker.points.push_back(end);
    }
  }
  return marker;
}
}  // namespace

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  const std::string package_share =
    ament_index_cpp::get_package_share_directory("ur3_image_writer");
  auto node_options = rclcpp::NodeOptions();
  node_options.arguments(
    {"--ros-args", "--params-file", package_share + "/config/image_writer.yaml"});
  node_options.append_parameter_override("use_sim_time", true);
  node_options.append_parameter_override(
    "robot_description_kinematics.ur_manipulator.kinematics_solver",
    "kdl_kinematics_plugin/KDLKinematicsPlugin");
  node_options.append_parameter_override(
    "robot_description_kinematics.ur_manipulator.kinematics_solver_search_resolution", 0.005);
  node_options.append_parameter_override(
    "robot_description_kinematics.ur_manipulator.kinematics_solver_timeout", 0.005);
  node_options.append_parameter_override(
    "robot_description_kinematics.ur_manipulator.kinematics_solver_attempts", 3);

  const auto node = rclcpp::Node::make_shared("write_image_node", node_options);
  const auto logger = node->get_logger();
  const std::string planning_group =
    node->declare_parameter<std::string>("planning_group", "ur_manipulator");
  std::string image_path =
    node->declare_parameter<std::string>("image_path", "resources/images/letter.png");
  const double path_height = node->declare_parameter<double>("path_height", 0.13);
  const double path_width = node->declare_parameter<double>("path_width", 0.08);
  const double min_contour_area =
    node->declare_parameter<double>("min_contour_area", 50.0);
  const double simplify_epsilon =
    node->declare_parameter<double>("simplify_epsilon", 2.0);
  const double resample_spacing =
    node->declare_parameter<double>("resample_spacing", 5.0);
  const bool invert = node->declare_parameter<bool>("invert", true);
  const double lift_height = node->declare_parameter<double>("lift_height", 0.06);
  const double draw_offset_z = node->declare_parameter<double>("draw_offset_z", 0.03);
  const double eef_step = node->declare_parameter<double>("eef_step", 0.005);
  const double min_fraction = node->declare_parameter<double>("min_fraction", 0.999);
  const bool avoid_collisions = node->declare_parameter<bool>("avoid_collisions", true);
  const bool execute_motion = node->declare_parameter<bool>("execute_motion", true);
  const double transit_velocity_scale =
    node->declare_parameter<double>("transit_velocity_scale", 0.3);
  const double draw_velocity_scale =
    node->declare_parameter<double>("draw_velocity_scale", 0.1);
  const std::string named_start =
    node->declare_parameter<std::string>("named_start", "test_configuration");
  const double marker_latch_seconds =
    node->declare_parameter<double>("marker_latch_seconds", 60.0);

  if (!image_path.empty() && image_path.front() != '/') {
    image_path = package_share + "/" + image_path;
  }

  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(node);
  std::thread spinner([&executor]() {executor.spin();});

  moveit::planning_interface::MoveGroupInterface move_group(node, planning_group);
  move_group.setPlanningTime(10.0);
  move_group.setNumPlanningAttempts(10);
  move_group.setMaxVelocityScalingFactor(0.1);
  move_group.setMaxAccelerationScalingFactor(0.1);
  move_group.setPoseReferenceFrame("world");

  if (!move_group.getCurrentState(10.0)) {
    executor.cancel();
    spinner.join();
    rclcpp::shutdown();
    return 1;
  }
  move_group.setMaxVelocityScalingFactor(transit_velocity_scale);
  const double safe_start_offset = draw_offset_z + lift_height;
  RCLCPP_INFO(
    logger, "Moving directly to %.3f m above named target '%s'.",
    safe_start_offset, named_start.c_str());
  if (!ur3_image_writer::moveToNamedTargetWithVerticalOffset(
      move_group, named_start, logger, safe_start_offset, execute_motion))
  {
    RCLCPP_ERROR(logger, "Could not reach the safe writing start pose.");
    executor.cancel();
    spinner.join();
    rclcpp::shutdown();
    return 1;
  }

  auto current_pose = move_group.getCurrentPose().pose;
  current_pose.position.z -= lift_height;

  ur3_image_writer::ImagePathOptions options;
  options.cartesian_height = path_height;
  options.cartesian_width = path_width;
  options.min_contour_area = min_contour_area;
  options.simplify_epsilon = simplify_epsilon;
  options.resample_spacing = resample_spacing;
  options.invert = invert;

  ur3_image_writer::Strokes strokes;
  try {
    strokes = ur3_image_writer::createStrokesFromImage(image_path, current_pose, options);
  } catch (const std::exception & error) {
    RCLCPP_ERROR(logger, "Image processing failed: %s", error.what());
    executor.cancel();
    spinner.join();
    rclcpp::shutdown();
    return 1;
  }
  RCLCPP_INFO(logger, "Created %zu stroke(s) from '%s'.", strokes.size(), image_path.c_str());

  const auto marker = createMarker(strokes, "world");
  auto marker_pub = node->create_publisher<visualization_msgs::msg::MarkerArray>(
    "letter_path_markers", rclcpp::QoS(1).transient_local().reliable());
  visualization_msgs::msg::MarkerArray marker_array;
  marker_array.markers.push_back(marker);
  marker_pub->publish(marker_array);
  auto marker_timer = node->create_wall_timer(
    std::chrono::milliseconds(500),
    [marker_pub, marker_array]() {marker_pub->publish(marker_array);});

  const bool succeeded = ur3_image_writer::executeCartesianStrokes(
    move_group, strokes, logger, lift_height, eef_step, min_fraction,
    avoid_collisions, execute_motion, transit_velocity_scale, draw_velocity_scale);
  if (!succeeded) {
    RCLCPP_ERROR(logger, "Could not execute the complete image path.");
  }

  if (marker_latch_seconds > 0.0) {
    rclcpp::sleep_for(
      std::chrono::milliseconds(static_cast<int>(marker_latch_seconds * 1000.0)));
  }
  executor.cancel();
  spinner.join();
  rclcpp::shutdown();
  return succeeded ? 0 : 1;
}
