#include "ur3_image_writer/image_path_processor.hpp"

#include <algorithm>
#include <cmath>
#include <limits>
#include <map>
#include <set>
#include <stdexcept>
#include <utility>
#include <vector>

#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/ximgproc.hpp>

namespace ur3_image_writer
{
namespace
{
using PixelPath = std::vector<cv::Point2d>;
using Pixel = cv::Point;
using Edge = std::pair<std::pair<int, int>, std::pair<int, int>>;

Edge makeEdge(const Pixel & first, const Pixel & second)
{
  const auto a = std::make_pair(first.y, first.x);
  const auto b = std::make_pair(second.y, second.x);
  return a < b ? std::make_pair(a, b) : std::make_pair(b, a);
}

std::vector<Pixel> neighbors(const cv::Mat & skeleton, const Pixel & point)
{
  std::vector<Pixel> result;
  for (int dy = -1; dy <= 1; ++dy) {
    for (int dx = -1; dx <= 1; ++dx) {
      if ((dx == 0 && dy == 0) || point.x + dx < 0 || point.y + dy < 0 ||
        point.x + dx >= skeleton.cols || point.y + dy >= skeleton.rows)
      {
        continue;
      }
      if (skeleton.at<uchar>(point.y + dy, point.x + dx) != 0) {
        result.emplace_back(point.x + dx, point.y + dy);
      }
    }
  }
  return result;
}

cv::Mat thin(const cv::Mat & binary)
{
  cv::Mat skeleton;
  cv::ximgproc::thinning(binary, skeleton, cv::ximgproc::THINNING_GUOHALL);
  return skeleton;
}

std::vector<std::vector<Pixel>> traceSkeleton(const cv::Mat & skeleton)
{
  std::vector<Pixel> pixels;
  std::map<std::pair<int, int>, std::vector<Pixel>> adjacency;
  for (int y = 0; y < skeleton.rows; ++y) {
    for (int x = 0; x < skeleton.cols; ++x) {
      if (skeleton.at<uchar>(y, x) != 0) {
        const Pixel point(x, y);
        pixels.push_back(point);
        adjacency[{y, x}] = neighbors(skeleton, point);
      }
    }
  }

  std::set<Edge> visited;
  std::vector<std::vector<Pixel>> paths;
  auto follow = [&](const Pixel & start, const Pixel & next) {
      std::vector<Pixel> path{start};
      Pixel previous = start;
      Pixel current = next;
      visited.insert(makeEdge(previous, current));
      while (true) {
        path.push_back(current);
        const auto & current_neighbors = adjacency.at({current.y, current.x});
        if (current_neighbors.size() != 2U) {
          break;
        }
        const Pixel candidate = current_neighbors[0] == previous ?
          current_neighbors[1] : current_neighbors[0];
        const Edge edge = makeEdge(current, candidate);
        if (visited.count(edge) != 0U) {
          break;
        }
        visited.insert(edge);
        previous = current;
        current = candidate;
      }
      if (path.size() >= 2U) {
        paths.push_back(path);
      }
    };

  for (const auto & point : pixels) {
    const auto & point_neighbors = adjacency.at({point.y, point.x});
    if (point_neighbors.size() == 2U) {
      continue;
    }
    for (const auto & next : point_neighbors) {
      if (visited.count(makeEdge(point, next)) == 0U) {
        follow(point, next);
      }
    }
  }
  for (const auto & point : pixels) {
    for (const auto & next : adjacency.at({point.y, point.x})) {
      if (visited.count(makeEdge(point, next)) == 0U) {
        follow(point, next);
      }
    }
  }
  return paths;
}

PixelPath resamplePath(const std::vector<cv::Point> & path, const double spacing)
{
  PixelPath sampled;
  if (path.size() < 2 || spacing <= 0.0) {
    return sampled;
  }

  sampled.emplace_back(path.front());
  double distance_until_sample = spacing;
  cv::Point2d segment_start = path.front();
  for (std::size_t i = 1; i < path.size(); ++i) {
    const cv::Point2d segment_end = path[i];
    cv::Point2d direction = segment_end - segment_start;
    double segment_length = cv::norm(direction);
    while (segment_length >= distance_until_sample && segment_length > 0.0) {
      const double ratio = distance_until_sample / segment_length;
      segment_start += direction * ratio;
      sampled.push_back(segment_start);
      direction = segment_end - segment_start;
      segment_length = cv::norm(direction);
      distance_until_sample = spacing;
    }
    distance_until_sample -= segment_length;
    segment_start = segment_end;
  }

  if (cv::norm(sampled.back() - cv::Point2d(path.back())) > 1e-6) {
    sampled.emplace_back(path.back());
  }
  return sampled;
}
}  // namespace

Strokes createStrokesFromImage(
  const std::string & image_path,
  const geometry_msgs::msg::Pose & reference_pose,
  const ImagePathOptions & options)
{
  const cv::Mat grayscale = cv::imread(image_path, cv::IMREAD_GRAYSCALE);
  if (grayscale.empty()) {
    throw std::runtime_error("Could not load image: " + image_path);
  }
  if (options.cartesian_height <= 0.0 || options.cartesian_width <= 0.0 ||
    options.simplify_epsilon < 0.0 || options.resample_spacing <= 0.0)
  {
    throw std::invalid_argument("Image path dimensions and sampling parameters are invalid.");
  }

  cv::Mat blurred;
  cv::GaussianBlur(grayscale, blurred, cv::Size(3, 3), 0.0);
  cv::Mat binary;
  const int threshold_mode = options.invert ? cv::THRESH_BINARY_INV : cv::THRESH_BINARY;
  cv::threshold(blurred, binary, 0.0, 255.0, threshold_mode | cv::THRESH_OTSU);

  std::vector<PixelPath> pixel_strokes;
  cv::Mat labels;
  cv::Mat stats;
  cv::Mat centroids;
  const int component_count = cv::connectedComponentsWithStats(
    binary, labels, stats, centroids, 8, CV_32S);
  cv::Mat filtered = cv::Mat::zeros(binary.size(), CV_8UC1);
  for (int label = 1; label < component_count; ++label) {
    if (stats.at<int>(label, cv::CC_STAT_AREA) < options.min_contour_area) {
      continue;
    }
    filtered.setTo(255, labels == label);
  }

  const auto skeleton = thin(filtered);
  auto paths = traceSkeleton(skeleton);
  std::sort(
    paths.begin(), paths.end(), [](const auto & left, const auto & right) {
      const auto left_box = cv::boundingRect(left);
      const auto right_box = cv::boundingRect(right);
      return left_box.x == right_box.x ? left_box.y < right_box.y : left_box.x < right_box.x;
    });
  for (const auto & path : paths) {
    if (cv::arcLength(path, false) < std::max(2.0, options.simplify_epsilon)) {
      continue;
    }
    std::vector<cv::Point> simplified;
    cv::approxPolyDP(path, simplified, options.simplify_epsilon, false);
    auto sampled = resamplePath(simplified, options.resample_spacing);
    if (sampled.size() >= 2) {
      pixel_strokes.push_back(sampled);
    }
  }
  if (pixel_strokes.empty()) {
    throw std::runtime_error("No usable contours found in image: " + image_path);
  }

  double min_u = std::numeric_limits<double>::max();
  double max_u = std::numeric_limits<double>::lowest();
  double min_v = std::numeric_limits<double>::max();
  double max_v = std::numeric_limits<double>::lowest();
  for (const auto & stroke : pixel_strokes) {
    for (const auto & point : stroke) {
      min_u = std::min(min_u, point.x);
      max_u = std::max(max_u, point.x);
      min_v = std::min(min_v, point.y);
      max_v = std::max(max_v, point.y);
    }
  }

  const double pixel_width = max_u - min_u;
  const double pixel_height = max_v - min_v;
  if (pixel_width <= 0.0 || pixel_height <= 0.0) {
    throw std::runtime_error("Extracted image path has zero width or height.");
  }
  const double scale = std::min(
    options.cartesian_width / pixel_width,
    options.cartesian_height / pixel_height);
  const double center_u = (min_u + max_u) / 2.0;
  const double center_v = (min_v + max_v) / 2.0;

  Strokes cartesian_strokes;
  for (const auto & pixel_stroke : pixel_strokes) {
    Stroke cartesian_stroke;
    cartesian_stroke.reserve(pixel_stroke.size());
    for (const auto & pixel : pixel_stroke) {
      auto pose = reference_pose;
      pose.position.x += (center_v - pixel.y) * scale;
      pose.position.y += (pixel.x - center_u) * scale;
      cartesian_stroke.push_back(pose);
    }
    cartesian_strokes.push_back(cartesian_stroke);
  }
  return cartesian_strokes;
}

std::vector<geometry_msgs::msg::Pose> createMotionWaypoints(
  const Strokes & strokes,
  const double lift_height)
{
  std::vector<geometry_msgs::msg::Pose> waypoints;
  for (const auto & stroke : strokes) {
    if (stroke.empty()) {
      continue;
    }
    auto above_start = stroke.front();
    above_start.position.z += lift_height;
    auto above_end = stroke.back();
    above_end.position.z += lift_height;
    waypoints.push_back(above_start);
    waypoints.push_back(stroke.front());
    waypoints.insert(waypoints.end(), stroke.begin(), stroke.end());
    waypoints.push_back(above_end);
  }
  return waypoints;
}

std::vector<geometry_msgs::msg::Pose> createStrokeWaypoints(
  const Stroke & stroke,
  const double lift_height)
{
  if (stroke.empty()) {
    return {};
  }
  std::vector<geometry_msgs::msg::Pose> waypoints;
  waypoints.reserve(stroke.size() + 1U);
  waypoints.insert(waypoints.end(), stroke.begin(), stroke.end());
  auto above_end = stroke.back();
  above_end.position.z += lift_height;
  waypoints.push_back(above_end);
  return waypoints;
}
}  // namespace ur3_image_writer
