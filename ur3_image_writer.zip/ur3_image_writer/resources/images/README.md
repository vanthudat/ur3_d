# Input Images

Place input PNG or JPEG files in this directory. The default configuration
currently uses `anhchuD.png`, with dark writing on a light background.
